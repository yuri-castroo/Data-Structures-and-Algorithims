/*
Implement Adjacency List
 coulndt firgure out the Dijkstra’s shortest path algorithm
 */
#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std;

struct AdjListNode
{
    int dest;
    float weight;
    struct AdjListNode* next;
};

struct AdjList
{
    struct AdjListNode *head;
};


class Graph
{
private:
    int V;
    struct AdjList* array;
public:
    Graph(int V)
    {
        this->V = V;
        array = new AdjList [V];
        for (int i = 0; i < V; ++i)
            array[i].head = NULL;
    }

    AdjListNode* newAdjListNode(int dest, float weight)
    {
        AdjListNode* newNode = new AdjListNode;
        newNode->dest = dest;
        newNode->next = NULL;
        newNode->weight = weight;
        return newNode;
    }

    void addEdge(int source, int dest, float weight)
    {
        AdjListNode* newNode = newAdjListNode(dest,weight);
        newNode->next = array[source].head;
        array[source].head = newNode;
        newNode = newAdjListNode(source,weight);
        newNode->next = array[dest].head;
        array[dest].head = newNode;
        
    }

    void printGraph()
    {
        int v;
        for (v = 0; v < V; ++v)
        {
            AdjListNode* pCrawl = array[v].head;
            cout<<"\n list of vertex "<< v <<"\n head ";
            while (pCrawl)
            {
                cout<<"-> "<< pCrawl->dest << " weight: " <<pCrawl->weight << " ";
                pCrawl = pCrawl->next;
            }
            cout<<endl;
        }
    }
    
    //void shortPath(){}
};

//~~~~~~~~~~~~~~~~~~~~~~~~~~MAIN~~~~~~~~~~~~~~~~~~~~~~~~~~//
int main()
{
    int vertices, edges, source, destination;
    float weight;
    ifstream infile("graph.txt");
     
    if (infile.is_open()){
        infile >> vertices >> edges;
        
        cout << "v: " << vertices << "e: " << edges << endl;
        
        Graph gh(vertices);
        
        for (int i = 1; i <= edges; i++){
            infile>>source>>destination>>weight;
            cout <<  source << " " << destination << " " << weight << endl;
            gh.addEdge(source,destination,weight);
        }
        
        gh.printGraph();
    }
    else
        cout << "Unable to open file" << endl;

    return 0;
}
